def add(a,b):
    return(a+b)
a,b=map(int,input().split())
print(add(a,b))
def sub(a,b):
    return(a-b)
a,b=map(int,input().split())
print(sub(a,b))
def mul(a,b):
    return(a*b)
a,b=map(int,input().split())
print(mul(a,b))
def div(a,b):
    return(a/b)
a,b=map(int,input().split())
print(div(a,b))
